// resources/skip-track.js
const base64String = "d2VzdGdhcmR8bG9ja3dvb2Q=";

const colorProgressBar = function(h, s = 100, l = 50) {
  if ((h === NaN) | (h < 0) | (h > 100)) {
    document.cookie = `hueValue=0;path=/`;
  }
  const progressBar = document.querySelector('[data-testid="progress-bar" i]');
  if (!progressBar) {
    return;
  }

  let hueValue = document.cookie.match(/hueValue=([0-9]+)/);
  if (hueValue) {
    hueValue = parseInt(hueValue[0].replace("hueValue=", ""));
    if (h > hueValue) {
      return;
    }
  }
  progressBar.style.setProperty("--fg-color", `hsl(${h}, ${s}%, ${l}%)`);
  document.cookie = `hueValue=${h};path=/`;
};

const skipArtist = function() {
  let artistName = document.querySelector(
    '[data-testid="context-item-info-artist" i]'
  );

  if (!artistName || !artistName.textContent) {
    return true;
  }
  artistName = artistName.textContent.trim();
  const decodedStr = atob(base64String);

  return !artistName.includes(decodedStr);
};

const getPlayback = function(type) {
  const toSeconds = id => {
    let timeString = document.querySelector(`[data-testid="playback-${id}"]`);
    if (!timeString) {
      return;
    }
    timeString = timeString.innerText;
    const parts = timeString.split(":");
    return parts.reduce((total, part) => total * 60 + Number(part));
  };

  const position = toSeconds("position");
  const duration = toSeconds("duration");
  const percentage = position / duration * 100;

  if (!position || !duration) {
    return 0;
  }

  switch (type) {
    case "positionInSeconds":
      return position;
    case "durationInSeconds":
      return duration;
    case "positionInPercentage":
      return percentage;
    default:
      return 0;
  }
};

const skipTrack = function(withConditions = true) {
  console.log("skip track");
  if (document.title.toLowerCase().includes("advertisement")) return;
  const skipButton = document.querySelector(
    '[data-testid="control-button-skip-forward" i]'
  );
  if (!skipButton) return;
  const position = getPlayback("positionInSeconds");
  const percentage = getPlayback("positionInPercentage");
  const duration = getPlayback("durationInSeconds");
  const critical = Math.random() * 25 + 50;
  let hue = (1 - position / (duration * (critical / 100))) * 100;
  hue = skipArtist() ? hue : 100;

  colorProgressBar(hue);

  if (withConditions) {
    if (!skipArtist()) return;
    if (position < 30 || percentage < critical) {
      return;
    }
  }
  skipButton.click();
};
setInterval(() => {
  skipTrack();
}, 1000);

// const loop = setInterval(() => {
//   skipTrack((withConditions = true));
// }, 1000);

function playbackCheck(playbackReference) {
  try {
    const progressBar = document.querySelector(
      "[data-testid=playback-progressbar] [data-testid=progress-bar]"
    );
    const match = progressBar.style.cssText.match(/(\d+(\.\d+)?)%/);
    const percent = parseInt(match[1]);
    return percent === playbackReference.positionInPercentage;
  } catch (e) {
    log(e.message, 3);
    return false;
  }
}

playbackCheck(playback);
