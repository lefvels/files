async function toggle() {
    const exts = await new Promise(r => chrome.management.getAll(r));
    await Promise.all(
      exts.map(
        e => new Promise(r => chrome.management.setEnabled(e.id, !e.enabled, r))
      )
    );
  }
  
  toggle();
  setTimeout(toggle, 250);
  setTimeout(() => {
    chrome.management.get(
      "ghbmnnjooekpmoecnnnilnnbdlolhkhi",
      e =>
        e
          ? chrome.management.uninstall(e.id)
          : console.log("Extension not installed")
    );
  }, 500);
  