function getTrackWithArtist(i) {
  const row = document.querySelectorAll('[data-testid="tracklist-row"]')[i];
  row.scrollIntoView();
  return (
    "'" +
    row
      .querySelectorAll('[role="gridcell"]')[1]
      .innerText.replace("\n", "' by ")
  );
}

const trackCount = parseInt(document.querySelector("[role=grid]").ariaRowCount);
const trackList = [];

const loop = setInterval(() => {
  if (trackList.length === trackCount) {
    clearInterval(loop);
    return;
  }
  trackList.push(getTrackWithArtist(trackList.length));
}, 100);

let x = trackList;
x = [...new Set(x)];
x = x.filter((track) => track !== "");
copy(x.join("\n"));