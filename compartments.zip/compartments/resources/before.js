// before.js
if (window.location.href.includes("open.spotify.com")) {
  // Clear cache
  caches.keys().then(names => {
    names.forEach(name => {
      caches.delete(name);
    });
  });

  // Clear IndexedDB
  indexedDB.databases().then(dbs => {
    dbs.forEach(db => {
      indexedDB.deleteDatabase(db.name);
    });
  });

  // Clear service workers
  navigator.serviceWorker.getRegistrations().then(registrations => {
    registrations.forEach(registration => {
      registration.unregister();
    });
  });

  // Filter cookies to only get Spotify cookies
  const spotifyCookies = document.cookie
    .split(";")
    .filter(cookie => cookie.startsWith("spotify") || cookie.startsWith("sp_"));

  // Iterate through the Spotify cookies
  spotifyCookies.forEach(cookie => {
    // Split the cookie into name/value pairs
    const cookieName = cookie.split("=")[0].trim();

    // Set the expiration date in the past to delete the cookie
    document.cookie = `${cookieName}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/; domain=.spotify.com`;
    document.cookie = "hue=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
  });

  let keys = Object.keys(localStorage);
  const anonymousKeys = keys.filter(key => key.startsWith("anonymous:"));
  for (let key of anonymousKeys) {
    localStorage.removeItem(key);
  }

  keys = Object.keys(localStorage)
    .map(i => i.split(":")[0])
    .filter(i => !i.includes("anonymous"))
    .filter(i => i.match(/^[a-z0-9]+$/));
  if (keys.length > 5) {
    let count = {};

    keys.forEach(i => {
      count[i] = (count[i] || 0) + 1;
    });

    const userID = Object.keys(count).reduce(
      (a, b) => (count[a] > count[b] ? a : b)
    );
    const randomVolume = Math.random() * (0.99 - 0.5) + 0.5;
    localStorage.setItem("playback", JSON.stringify({ volume: randomVolume }));

    const keysToSet = {
      "nav-bar-width": 0,
      "panel-width": 0,
      "ylx-sidebar-state": 1,
      "ylx-default-state-nav-bar-width": 0,
      "ylx-expanded-state-nav-bar-width": 0,
      toggleNowPlayingView: false,
      isPlaybackBarRemainingTimeToggled: false,
      "npv-onboarding-dismissed": true,
      "npv-onboarding-never-show-again": true,
      toggleNowPlayingView: false,
      "ui.right_sidebar_content": "disabled"
    };
    for (const key in keysToSet) {
      const matchingKeys = Object.keys(localStorage).filter(
        i => i.includes(key) && !i.includes("anonymous")
      );

      matchingKeys.forEach(localStorageKey => {
        console.log(
          "Setting local storage value",
          key,
          matchingKeys,
          localStorageKey
        );
      });

      matchingKeys.forEach(localStorageKey => {
        localStorage.removeItem(localStorageKey);
      });

      const newKey = `${userID}:${key}`;
      localStorage.setItem(newKey, keysToSet[key]);
    }
  } else {
    console.log("Login required to set local storage values");
  }
}

/*
  // Remove all keys starting with "anonymous"
  Object.keys(localStorage).forEach(key => {
    if (key.startsWith("anonymous:")) localStorage.removeItem(key);
  });

  // Filter keys that don't include "anonymous", and match /^[a-z0-9]+$/
  let keys = Object.keys(localStorage).filter(key => {
    let i = key.split(":")[0];
    return !i.includes("anonymous") && /^[a-z0-9]+$/.test(i);
  });

  if (keys.length > 5) {
    // Count occurrences of each key
    let count = keys.reduce((acc, i) => {
      acc[i] = (acc[i] || 0) + 1;
      return acc;
    }, {});

    const userID = Object.keys(count).reduce(
      (a, b) => (count[a] > count[b] ? a : b)
    );

    // Store random volume
    const randomVolume = Math.random() * (0.99 - 0.5) + 0.5;
    localStorage.setItem("playback", JSON.stringify({ volume: randomVolume }));

    // Define keys to set
    const keysToSet = {
      isPlaybackBarRemainingTimeToggled: false,
      "nav-bar-width": 200,
      "npv-onboarding-dismissed": true,
      "npv-onboarding-never-show-again": true,
      "panel-width": 200,
      toggleNowPlayingView: false,
      "ui.right_sidebar_content": "disabled",
      "ylx-default-state-nav-bar-width": 200,
      "ylx-expanded-state-nav-bar-width": 200,
      "ylx-sidebar-state": 1
    };

    Object.keys(keysToSet).forEach(key => {
      const matchingKeys = Object.keys(localStorage).filter(
        i => i.includes(key) && !i.includes("anonymous")
      );

      // Remove all matching keys
      matchingKeys.forEach(localStorageKey => {
        localStorage.removeItem(localStorageKey);
      });

      // Set new key-value pair
      const newKey = `${userID}:${key}`;
      localStorage.setItem(newKey, keysToSet[key]);
    });

    // Clear 'hue' cookie
    document.cookie = "hue=; expires=Thu, 01 Jan 1970 00:00:00 UTC";
  } else {
    console.log("Login required to set local storage values");
  }
}
*/
// before.js [chrome extension file]
// This file is used to set the localStorage keys.
