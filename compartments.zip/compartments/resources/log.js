function log(message, type = 1) {
  let style;
  let symbolStyle;
  let symbol;

  if (type === 1) {
    style = "color: lightblue";
    symbolStyle = "color: lightblue; font-size: 15px;";
    symbol = "\u2139";
  } else if (type === 2) {
    style = "color: orange;";
    symbolStyle = "color: orange; font-size: 20px; font-weight: bold";
    symbol = "\u26A0";
  } else if (type === 3) {
    style = "color: red;";
    symbolStyle = "color: red; font-size: 20px; font-weight: bold";
    symbol = "\u2715";
  }
  console.info(`%c${symbol} %c${message}`, symbolStyle, style);
}