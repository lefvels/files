// resources/login.js (this code will be executed after page load)


