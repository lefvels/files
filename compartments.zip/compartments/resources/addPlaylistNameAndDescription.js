/* eslint-disable */
var Mailjs = (function(o) {
  "use strict";
  return class {
    constructor() {
      (this.baseUrl = "https://api.mail.tm"), (this.token = ""), (this.id =
        ""), (this.address = "");
    }
    register(t, s) {
      return this.send_("/accounts", "POST", { address: t, password: s });
    }
    async login(t, s) {
      s = await this.send_("/token", "POST", { address: t, password: s });
      return s.status &&
        (
          (this.token = s.data.token),
          (this.id = s.data.id),
          (this.address = t)
        ), s;
    }
    async loginWithToken(t) {
      this.token = t;
      t = await this.me();
      if (t.status)
        return (this.id = t.data.id), (this.address = t.data.address), t;
      throw new Error(t.message);
    }
    me() {
      return this.send_("/me");
    }
    getAccount(t) {
      return this.send_("/accounts/" + t);
    }
    deleteAccount(t) {
      return this.send_("/accounts/" + t, "DELETE");
    }
    deleteMe() {
      return this.deleteAccount(this.id);
    }
    getDomains() {
      return this.send_("/domains?page=1");
    }
    getDomain(t) {
      return this.send_("/domains/" + t);
    }
    getMessages(t = 1) {
      return this.send_("/messages?page=" + t);
    }
    getMessage(t) {
      return this.send_("/messages/" + t);
    }
    deleteMessage(t) {
      return this.send_("/messages/" + t, "DELETE");
    }
    setMessageSeen(t, s = !0) {
      return this.send_("/messages/" + t, "PATCH", { seen: s });
    }
    getSource(t) {
      return this.send_("/sources/" + t);
    }
    async createOneAccount() {
      let t = await this.getDomains();
      if (!t.status) return t;
      t = t.data[0].domain;
      var s = this.makeHash_(5) + "@" + t,
        e = this.makeHash_(8);
      let a = await this.register(s, e);
      if (!a.status) return a;
      a = a.data;
      let n = await this.login(s, e);
      return n.status
        ? ((n = n.data), { status: !0, data: { username: s, password: e } })
        : n;
    }
    makeHash_(t) {
      return Array.from({ length: t }, () => {
        var t = "abcdefghijklmnopqrstuvwxyz0123456789";
        return t.charAt(Math.floor(Math.random() * t.length));
      }).join("");
    }
    async send_(t, s = "GET", e) {
      const a = {
        method: s,
        headers: {
          accept: "application/json",
          authorization: "Bearer " + this.token
        }
      };
      if ("POST" === s || "PATCH" === s) {
        const i = "PATCH" === s ? "merge-patch+json" : "json";
        (a.headers["content-type"] =
          "application/" + i), (a.body = JSON.stringify(e));
      }
      const n = await o(this.baseUrl + t, a);
      let r;
      const i = n.headers.get("content-type");
      return (r =
        null !== i && void 0 !== i && i.startsWith("application/json")
          ? await n.json()
          : await n.text()), {
        status: n.ok,
        message: n.ok ? "ok" : r.message || r.detail,
        data: r
      };
    }
  };
})(fetch);

const mailjs = new Mailjs();

async function getLast() {
  await mailjs.login("playlist@diginey.com", "playlist!");
  const messagesPromise = mailjs.getMessages();
  const [messages] = await Promise.all([messagesPromise]);
  const messageId = messages.data[0].id;
  const latestMessagePromise = mailjs.getMessage(messageId);
  const [latestMessage] = await Promise.all([latestMessagePromise]);
  const messageContent = JSON.parse(latestMessage.data.subject);
  const deleteMessagePromise = mailjs.deleteMessage(messageId);
  await Promise.all([deleteMessagePromise]);
  return messageContent;
}


const ND = await getLast();

// const ND = {name: 'Timeless Tranquility: A Journey Through Music for the Soul ', description: 'Escape into the calming and therapeutic sounds of …ances that soothe the spirit and uplift the mind.'}

async function I(selector, value) {
  const element = document.querySelector(selector);
  if (element.disabled) return;
  element.focus();

  if (element.tagName === "SELECT") {
    element.selectedIndex = value;
  } else if (element.tagName === "SPAN") {
    element.textContent += value;
  } else if (element.tagName === "INPUT" || element.tagName === "TEXTAREA") {
    var nativeInputValueSetter;
    if (element.tagName === "INPUT") {
      nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
    } else if (element.tagName === "TEXTAREA") {
      nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value").set;
    }
    nativeInputValueSetter.call(element, value);
    var ev2 = new Event('input', { bubbles: true});
    element.dispatchEvent(ev2);
  }
  element.dispatchEvent(new Event("change", { bubbles: true }));
  [...element.attributes]
    .filter((attr) => attr.name.includes("_react"))
    .forEach((reactAttr) => {
      const events = ["change", "keydown", "keyup", "mouseenter"];
      events.forEach((event) => {
        if (typeof element[reactAttr.name][event] === "function") {
          element[reactAttr.name][event]({
            target: {
              value
            }
          });
        }
      });
      if (typeof element[reactAttr.name].blur === "function") {
        element[reactAttr.name].blur();
      }
    });
}

// Constants for selectors
const SELECTORS = {
    name: '[data-testid="playlist-edit-details-name-input"]',
    description: '[data-testid="playlist-edit-details-description-input"]',
    save: '[data-testid="playlist-edit-details-save-button"]',
  };
  
  const simulateClick = async (element) => {
    const mousedownEvent = new Event("mousedown", { bubbles: true, cancelable: true });
    const mouseupEvent = new Event("mouseup", { bubbles: true, cancelable: true });
    const clickEvent = new Event("click", { bubbles: true, cancelable: true });
  
    element.dispatchEvent(mousedownEvent);
    element.dispatchEvent(mouseupEvent);
    element.dispatchEvent(clickEvent);
  };
  
  const setInputValue = async (selector, value) => {
    const inputElement = document.querySelector(selector);
    await I(selector, value);
    await simulateClick(inputElement);
  };
  
  document.querySelector('h1').click();
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  await setInputValue(SELECTORS.name, ND.name);
  await setInputValue(SELECTORS.description, ND.description);
  
  const saveBtn = document.querySelector(SELECTORS.save);
  await simulateClick(saveBtn);



  const loop = setInterval(async () => {
  await setInputValue('textarea', 'go');
  await new Promise(resolve => setTimeout(resolve, 1000));
  const sendBtn = document.querySelector('[class*=ChatMessageSendButton_sendButton]').click()
  await simulateClick(sendBtn);
  }, 1000);