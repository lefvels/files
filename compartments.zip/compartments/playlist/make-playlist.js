async function fetchTrackIDs(url) {
  const response = await fetch(url);
  const html = await response.text();
  const regex = /https:\/\/open.spotify.com\/track\/\w+/g;
  let matches = html.match(regex);
  return matches?.map((url) => url.split("/track/")[1]);
}

function getRandomSubset(array, min, max) {
  const shuffled = array.sort(() => Math.random() - 0.5);
  const length = getRandomInt(min, max);
  return shuffled.slice(0, length);
}

function getRandomInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

async function fetchPlaylistTrackIDs(playlistID) {
  const url = `https://open.spotify.com/playlist/${playlistID}`;
  return fetchTrackIDs(url);
}

async function getRandomTrackIDs() {
  const playlists = [
    "7Aw1kKscpkOjKkSchtAvD1",
    "7wzjHF7lD5c14vkbxxg1Xv",
    "24s47XRZ4ofsqC60tR4zyZ",
    "37i9dQZF1DX561TxkFttR4",
    "37i9dQZF1DWURCUKHUKWCX",
    "37i9dQZF1DX7R7Bjxm48PR",
    "37i9dQZF1DX65caF1CvtIN",
    "37i9dQZF1DX7K31D69s4M1",
    "37i9dQZF1DX3TPMgP3ojGS",
    "37i9dQZF1DX4sWSpwq3LiO",
    "37i9dQZF1DXcEKFjZJYZcc",
    "5QMSAYxW2sURk7vO2KPoft"
  ];

  const playlistTracks = await Promise.all(
    playlists.map(fetchPlaylistTrackIDs)
  );
  const allTracks = playlistTracks.flat();
  const randomSubset = getRandomSubset(allTracks, 50, 100);
  return randomSubset.map((id) => `https://open.spotify.com/track/${id}`);
}

function simulateClipboardPaste() {
  const pasteEvent = new KeyboardEvent("keydown", {
    bubbles: true,
    cancelable: true,
    keyCode: 86,
    metaKey: true
  });
  document.dispatchEvent(pasteEvent);
}

function copyTextToClipboard(text) {
  const textarea = document.createElement("textarea");
  textarea.value = text;
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand("copy");
  textarea.remove();
}

async function pasteTrackIDs() {
  const tracks = await getRandomTrackIDs();
  const trackList = tracks.join("\n");
  window.addEventListener('focus', function() {
    copyTextToClipboard(trackList);
    simulateClipboardPaste();
    copyTextToClipboard('');
  });  
  const duplicatePopup = document.querySelector('[aria-label="Already added"]');
  if (duplicatePopup) {
    duplicatePopup.querySelectorAll("button")[1].click();
  }
}

setTimeout(pasteTrackIDs, 5000);