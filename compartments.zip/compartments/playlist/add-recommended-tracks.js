// add recomended tracks based on what’s in the playlist
const recommendedTracks = document.querySelector(
  '[data-testid="recommended-track"]'
);
const refreshButton = [...recommendedTracks.querySelectorAll("button")].pop();

refreshButton.click();

// Define addToPlaylist as a prototype method
HTMLElement.prototype.addToPlaylist = function() {
  this.querySelector('[data-testid="add-to-playlist-button"]').click();
};

recommendedTracks
  .querySelectorAll('[data-testid="tracklist-row"]')[0]
  .addToPlaylist();

function isBottomRight(element) {
  const rect = element.getBoundingClientRect();
  const windowHeight = window.innerHeight;
  const windowWidth = window.innerWidth;
  const threshold = 0.5; // 50% of viewport
  return (
    rect.bottom > windowHeight * threshold &&
    rect.right > windowWidth * threshold
  );
}

function dismissOnboardingHook() {
  const root = document.querySelector("[data-tippy-root]");
  if(!root) return
  if (isBottomRight(root)) {
    const checkbox = root.querySelector('[type="checkbox"]');
    if (!checkbox.checked) {
      checkbox.checked = true;
      setTimeout(() => {
        root.querySelector("button").click();
      }, 1000);
    }
  }
}

dismissOnboardingHook();
