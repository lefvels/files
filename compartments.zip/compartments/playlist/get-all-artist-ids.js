const artistPath = "artist/7CEHEoNtFK7jcjgQwSO4PD/discography/all";
const artistURL = `${location.protocol}//${location.host}/${artistPath}`;

async function adjustIframeZoom(zoomLevel) {
  await discographyIframe.onload;
  const iframeDocument = discographyIframe.contentDocument;
  iframeDocument.documentElement.style.zoom = zoomLevel;
}

const discographyIframe = document.createElement("iframe");
discographyIframe.id = "discographyIframe";
discographyIframe.style.cssText = `
  position: fixed;
  width: 100%;
  height: 100%;
  border: none;
  overflow: hidden;
  pointer-events: none;
  background: transparent;
  opacity: 0.5;
  transition: opacity 0.5s ease;
`;
document.body.appendChild(discographyIframe);
discographyIframe.src = artistURL;

function getRandomSet(arr, size) {
  let shuffled = arr.slice(0);
  shuffled.sort(() => Math.random() - 0.5); 
  return shuffled.slice(0, size);
}



let trackIds = [];
let previousTrackIdsCount = 0;

const trackIdCheckInterval = setInterval(async () => {
  if (discographyIframe.contentDocument.readyState === "complete") {
    await adjustIframeZoom(0.1);

    const extractTrackIdsFromIframe = () => {
      const trackLinks = [
        ...discographyIframe.contentDocument.body.querySelectorAll(
          '[data-testid="internal-track-link"]'
        )
      ];
      const extractTrackIdFromUrl = (url) => url.split("track/")[1];
      const uniqueTrackIds = new Set(
        trackLinks.map((link) => extractTrackIdFromUrl(link.href))
      );
      return [...uniqueTrackIds];
    };

    const newTrackIds = extractTrackIdsFromIframe();
    trackIds = [...new Set([...trackIds, ...newTrackIds])]; // Merge old and new track ids removing duplicates

    if (previousTrackIdsCount === trackIds.length) {
      // No new track ids found, stop checking
      clearInterval(trackIdCheckInterval);
      // remove iframe
      document.body.removeChild(discographyIframe);
      trackIds = getRandomSet(Math.round(49*0.08), trackIds)
    } else {
      previousTrackIdsCount = trackIds.length; // Update the previous track ids count
    }
  }
}, 5000);

