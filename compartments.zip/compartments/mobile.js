function getArtistName() {
  const artistNameElement = document.querySelector('[data-testid*="metadata-container"]');
  if (
    !artistNameElement ||
    !artistNameElement.firstChild ||
    !artistNameElement.firstChild.lastChild
  ) {
    return null;
  }
  return artistNameElement.firstChild.lastChild.textContent.trim();
}

// Decode blacklist
function decodeBlacklist() {
  const base64String = "d2VzdGdhcmR8bG9ja3dvb2Q=";
  return atob(base64String).split("|");
}

// Check if artist is in blacklist
function isListedArtist() {
  let artistName = getArtistName();
  const blacklist = decodeBlacklist();
  if (artistName) {
    artistName = artistName.toLowerCase();
    return blacklist.some(artist => artistName.includes(artist));
  }
  return false;
}

// Main skip artist logic
function skipArtist() {
  const artistName = getArtistName();
  if (!artistName) {
    return true;
  }
  if (isListedArtist()) {
    return false;
  } else {
    return true;
  }
}

toSeconds = id => {
  let time = document.querySelector('[data-testid*="progress-bar-time-labels"]');
  if (!time) {
    return;
  }
  time = time.children[id];
  time = time.innerText;
  time = time.split(":");
  return time.reduce((total, part) => total * 60 + Number(part));
};

function getPlayback(type) {
  const position = toSeconds(0);
  const duration = toSeconds(1);
  const percentage = position / duration * 100;

  if (!position || !duration) {
    return 0;
  }

  switch (type) {
    case "positionInSeconds":
      return position;
    case "durationInSeconds":
      return duration;
    case "positionInPercentage":
      return percentage;
    default:
      return 0;
  }
}

function skipTrack(withConditions = false) {
  if (!skipArtist()) {
    return;
  }

  const skipButton = document.querySelector('[data-testid*="skip-forward-button"]');
  if (!skipButton) return;
  const position = getPlayback("positionInSeconds");
  const percentage = getPlayback("positionInPercentage");
  const duration = getPlayback("durationInSeconds");
  const critical = Math.random() * 25 + 50;
  if (withConditions) {
    if (position > 30 && percentage > critical) {
      skipButton.click();
    }
  } else {
    skipButton.click();
  }
}

function openTrackBiew() {
  const asideElement = document.querySelector("aside");
  const trackView = asideElement.querySelector('[data-testid*="container"]');
  if (trackView === null) {
    const nowPlayingBar = document.querySelector('[data-testid*="floating-now-playing-bar"]');
    if (nowPlayingBar === null) {
      return;
    }
    nowPlayingBar.click();
  }
}

function clickContinue() {
  const continueButtons = [...document.querySelectorAll("button")].filter(i =>
    i.textContent.toLocaleLowerCase().includes("continue")
  );
  if (continueButtons.length > 0) {
    continueButtons[0].click();
  }
}

(async function() {
  const loop = setInterval(async () => {
    clickContinue();
    await openTrackBiew();
    await skipTrack(withConditions = true);
  }, 1000);
})();
