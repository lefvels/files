const VERBOSE = false;

// Custom function to log messages to the console
function log(message, type = 1) {
  let style;
  let symbolStyle;
  let symbol;

  if (type === 1) {
    style = "color: lightblue";
    symbolStyle = "color: lightblue; font-size: 15px;";
    symbol = "\u2139";
  } else if (type === 2) {
    style = "color: orange;";
    symbolStyle = "color: orange; font-size: 20px; font-weight: bold";
    symbol = "\u26A0";
  } else if (type === 3) {
    style = "color: red;";
    symbolStyle = "color: red; font-size: 20px; font-weight: bold";
    symbol = "\u2715";
  }
  console.info(`%c${symbol} %c${message}`, symbolStyle, style);
}

const extensions = {
  buster: "mpbjkejclgfgadiemmefgebjfooflfhl",
  nopecha: "dknlfmjaanfblgfdfebhijalfmhmjjjo",
  webgl: "olnbjpaejebpnokblkepbphhembdicik",
  spoof: "facgnnelgcipeopfbjcajpaibhhdjgcp",
  signup: "nhdbgbhddngilnoffcoglmjfmjhkpapj"
};

const ids = {
  playingBar: ["now-playing-bar", "control-button-playpause"],
  playlistBar: ["action-bar-row", "play-button"],
  loginButton: ["[data-testid='login-button' i]"],
  repeatButton: ["[data-testid='control-button-repeat' i]"],
  shuffleButton: ["[data-testid='control-button-shuffle' i]"],
  muteButton: ["[data-testid='control-button-mute' i]"],
  playButton: ["[aria-label*='play' i]"],
  playlistPage: ["[data-testid='playlist-page' i] [role='grid']"],
  progressBar: ["[data-testid='progress-bar' i]"],
  volumeBar: ["[class*='volume-bar' i] input"],
  artistInfo: ["[data-testid='context-item-info-artist' i]"],
  skipButton: ["[data-testid='control-button-skip-forward' i]"],
  currentVolume: ["[data-testid='volume-bar' i] input"],
  closePanelButton: ["[data-testid='panelheader_close' i] button"],
  contextItemInfo: ["[data-testid*='context-item-info' i]"],
  leftSidebarFooter: ["[data-testid='left-sidebar-footer' i]"],
  saveToLibrary: ["[class*='control-button-heart' i]"],
  nowPlayingBar: ["[data-testid='now-playing-bar']"]
};

function getElement(selector) {
  return document.querySelector(selector);
}

const toggleExtension = (id, enable) => {
  try {
    chrome.runtime.sendMessage({
      type: "toggleExtension",
      id: id,
      enable: enable
    });
  } catch (e) {
    // log(`extension ${id} not found`, 3);
  }
};

toggleExtension(extensions.webgl, true);
toggleExtension(extensions.spoof, true);

function getPlaylists() {
  return (playlists = ["playlist", "folder"]
    .map(i => {
      return document.querySelector(
        `body [aria-labelledby*=':${i}'] [role=button]`
      );
    })
    .filter(i => i !== null));
}

function countdown(startCountdown) {
  let startTime;
  let count = 35;
  if (startCountdown) {
    startTime = new Date();
    const interval = setInterval(() => {
      const endTime = new Date();
      const timeDiff = endTime - startTime;
      const secondsPassed = Math.round(timeDiff / 1000);
      count = 35 - secondsPassed;
      document.cookie = `countdown=${count}`;
      if (count <= 0) {
        clearInterval(interval);
      }
    }, 100);
  } else {
    const cookieValue = document.cookie.replace(
      /(?:(?:^|.*;\s*)countdown\s*=\s*([^;]*).*$)|^.*$/,
      "$1"
    );
    count = cookieValue ? parseInt(cookieValue) : 30;
  }
  return count;
}

function advertisementCheck() {
  const ad = countdown();
  const isAdvertisement = document.title
    .toLowerCase()
    .includes("advertisement");
  countdown(isAdvertisement && ad === 0);
  if (ad > 30 && !isAdvertisement) {
    duplicateTab();
  }
  return isAdvertisement;
}

function repeatShuffleUnmute() {
  const repeatButton = document.querySelector(ids.repeatButton);
  if (!repeatButton) return;
  const shuffleButton = document.querySelector(ids.shuffleButton);
  const closePanelButton = document.querySelector(ids.closePanelButton);

  if (!advertisementCheck()) {
    if (repeatButton && repeatButton.ariaChecked !== "true")
      repeatButton.click();
    if (shuffleButton && shuffleButton.ariaChecked !== "true")
      shuffleButton.click();
    if (closePanelButton) {
      closePanelButton.click();
    }
  }
}

// Helper function to set color of progress bar
function colorProgressBar(h, s = 100, l = 50) {
  if (isNaN(h) | (h < 0) | (h > 100)) {
    document.cookie = `hue=0;path=/`;
  }
  const progressBar = document.querySelector('[data-testid="progress-bar" i]'); // ok
  let hue = document.cookie.match(/hue=([0-9]+)/);
  if (hue) {
    hue = parseInt(hue[0].replace("hue=", ""));
    if (h > hue) {
      return;
    }
  }
  progressBar.style.setProperty("--fg-color", `hsl(${h}, ${s}%, ${l}%)`);
  document.cookie = `hue=${h};path=/`;
}

// Get artist name
function getArtistName() {
  const artistNameElement = document.querySelector(ids.artistInfo);
  if (!artistNameElement || !artistNameElement.textContent) {
    return null;
  }
  return artistNameElement.textContent.trim();
}

// Decode blacklist
function decodeBlacklist() {
  const base64String = "d2VzdGdhcmR8bG9ja3dvb2Q=";
  return atob(base64String).split("|");
}

// Check if artist is in blacklist
function isListedArtist() {
  if (advertisementCheck()) {
    return false;
  }
  let artistName = getArtistName();
  const blacklist = decodeBlacklist();
  if (artistName) {
    artistName = artistName.toLowerCase();
    return blacklist.some(artist => artistName.includes(artist));
  }
  return false;
}

// Main skip artist logic
function skipArtist() {
  if (advertisementCheck()) {
    return true;
  }
  const artistName = getArtistName();
  if (!artistName) {
    return true;
  }
  if (isListedArtist()) {
    return false;
  } else {
    return true;
  }
}

function getTrackInfo() {
  return [
    ...new Set(
      [...document.querySelectorAll(ids.contextItemInfo)].map(e => e.innerText)
    )
  ].join(" — ");
}

function saveToLibrary(minHours = 3) {
  if (advertisementCheck()) {
    return;
  }
  const minSeconds = minHours * 60 * 60;
  let saveProbability = 1 / minSeconds * 5;
  if (!isListedArtist()) {
    saveProbability /= 2;
  }
  let heartButton = document.querySelector(ids.nowPlayingBar);
  if (!heartButton) {
    return;
  }
  heartButton = heartButton.querySelector(ids.cot);
  if (!heartButton) {
    return;
  }
  const hearted = heartButton.getAttribute("aria-checked");
  if (!hearted) {
    if (Math.random() < saveProbability) {
      heartButton.click();
      const trackInfo = getTrackInfo();
      log(`Added to library: ${trackInfo}`, 1);
    }
  }
}

// Helper function to convert mm:ss to seconds
const toSeconds = id => {
  let time = document.querySelector(`[data-testid='playback-${id}']`);
  if (!time) {
    return;
  }
  time = time.innerText;
  time = time.split(":");
  return time.reduce((total, part) => total * 60 + Number(part));
};

// Helper function to get playback values
function getPlayback(type) {
  const position = toSeconds("position");
  const duration = toSeconds("duration");
  const percentage = position / duration * 100;

  if (!position || !duration) {
    return 0;
  }

  switch (type) {
    case "positionInSeconds":
      return position;
    case "durationInSeconds":
      return duration;
    case "positionInPercentage":
      return percentage;
    default:
      return 0;
  }
}

function skipTrack(withConditions = false) {
  if (advertisementCheck()) {
    return;
  }
  if (!skipArtist()) {
    colorProgressBar(100);
    return;
  }

  const skipButton = document.querySelector(ids.skipButton); // '[data-testid="control-button-skip-forward" i]'
  if (!skipButton) return;
  const position = getPlayback("positionInSeconds");
  const percentage = getPlayback("positionInPercentage");
  const duration = getPlayback("durationInSeconds");
  const critical = Math.random() * 25 + 50;
  const hue = (1 - position / (duration * (critical / 100))) * 100;
  colorProgressBar(hue);

  if (withConditions) {
    document.title = `[${(critical - percentage).toFixed(
      1
    )}%] ${document.title.replace(/\[[0-9.]+%\]/g, "").trim()}`;
    if (position > 30 && percentage > critical) {
      const remaining = duration - position;
      const trackInfo = getTrackInfo();
      log(
        `${trackInfo} [skiped at ${percentage.toFixed(
          2
        )}%, with ${remaining} seconds remaining]`
      );
      skipButton.click();
    }
  } else {
    skipButton.click();
  }
}

async function simulateRightClickOnElement(selector) {
  const targetElement = document.querySelector(selector);
  const targetElementRect = targetElement.getBoundingClientRect();

  const clickPositionX = targetElementRect.left + targetElementRect.width / 2;
  const clickPositionY = targetElementRect.top;

  const simulatedRightClickEvent = new MouseEvent("contextmenu", {
    bubbles: true,
    cancelable: true,
    view: window,
    button: 2,
    buttons: 2,
    clientX: clickPositionX,
    clientY: clickPositionY
  });

  targetElement.dispatchEvent(simulatedRightClickEvent);
}

async function createEmptyPlaylist() {
  await simulateRightClickOnElement("[class*=content-glue]");
  const waitForTippy = setInterval(() => {
    let tippy = document.querySelector("[data-tippy-root] button");
    if (!tippy) return;
    tippy.click();
    clearInterval(waitForTippy);
  }, 1000);
}

function clickCloseButton() {
  const dialog = document.querySelector("[class*='dialog']");
  if (!dialog) return;
  let closeButtons = [...document.querySelectorAll("button")];
  if (!closeButtons) return;
  closeButtons.filter(i => i.innerText.toLowerCase().includes("close")).shift();
}

// Helper function to check if the displayed values match the progress bar position
function playbackCheck() {
  const playbackReference = getPlayback("positionInPercentage");
  const progressBar = document.querySelector('[data-testid="progress-bar" i]');
  if (!progressBar) {
    return false;
  }
  const match = progressBar.style.cssText.match(/(\d+(\.\d+)?)%/);
  const percent = parseInt(match[1]);
  return percent === parseInt(playbackReference);
}

// Helper function to check if playback is stuck
async function playbackStuck() {
  if (!playbackCheck) return true;
  // const duration = getPlayback("durationInSeconds");
  const t1 = getPlayback("positionInSeconds");
  await new Promise(resolve => setTimeout(resolve, 1000));
  const t2 = getPlayback("positionInSeconds");
  if (t2 === t1) {
    return true;
  }
  return false;
}

// Helper function to click on random track
async function clickRandomTrack() {
  const playlistPage = document.querySelector(
    "[data-testid=playlist-page] [role=grid]" // ok
  );

  if (!playlistPage) {
    log("Playlist page not found", 2);
    return;
  }

  const tracks = playlistPage.querySelectorAll('[aria-label*="play" i]'); // ok
  if (!tracks.length) {
    return;
  }

  const ind = Math.floor(Math.random() * tracks.length);
  const track = tracks[ind];

  scrollTo(track);
  try {
    scrollTo(tracks[ind - 2]);
  } catch (e) {}

  await new Promise(resolve => setTimeout(resolve, 300));
  track.dispatchEvent(
    new MouseEvent("dblclick", {
      bubbles: true,
      cancelable: true,
      view: window
    })
  );
}

function handlePlayback(id, returnStatus = false) {
  let play = document.querySelector(`[data-testid="${id[0]}"]`);
  if (!play) return;
  play = play.querySelector(`[data-testid="${id[1]}"]`);
  const isPaused =
    play.querySelector("svg path").outerHTML.match(/z/g).length === 1;
  if (returnStatus) {
    return isPaused ? "paused" : "playing";
  }
  if (isPaused) {
    play.click();
  }
}

function duplicateTab() {
  chrome.runtime.sendMessage({ message: "duplicateTab" }, function(response) {
    if (chrome.runtime.lastError) {
      console.error(chrome.runtime.lastError);
    } else {
      console.log("Response from background page:", response);
    }
  });
}

function isLoggedIn(login = true) {
  const x = document.querySelector(ids.loginButton) !== null;
  if (x) {
    toggleExtension(extensions.signup, x);
    toggleExtension(extensions.nopecha, x);
    toggleExtension(extensions.buster, x);
    return false;
  }
  if (login) {
    const loginButton = document.querySelector("[data-testid='login-button']");
    if (loginButton) {
      loginButton.previousSibling.click();
    }
  }
  return true;
}

function playingBarStatus() {
  const bar = document.querySelector("[data-testid=now-playing-bar]");
  if (!bar) return;
  return bar.innerHTML.match(/disabled/g) ? "disabled" : "enabled";
}

function forcePlay() {
  const playlistBar = handlePlayback(ids.playlistBar, true);
  const playingBar = handlePlayback(ids.playingBar, true);
  if (playingBar !== playlistBar) {
    log("Playlist changed", 1);
    handlePlayback(ids.playlistBar, false);
  }
}

function closeNowPlayingView() {
  let nowPlayingView = document.querySelector(ids.nowPlayingBar);
  if (!nowPlayingView) return;
  nowPlayingView = nowPlayingView.querySelector(
    "[data-testid='control-button-npv']"
  );
  if (nowPlayingView && nowPlayingView.getAttribute("data-active") === "true") {
    nowPlayingView.click();
  }
}

function collapseLibrary() {
  if (document.querySelector("nav").offsetWidth > 100) {
    document.querySelector("nav header button").click();
  }
}

function isBottomRight(x) {
  const rect = x.getBoundingClientRect();
  const windowHeight = window.innerHeight;
  const windowWidth = window.innerWidth;
  const threshold = 0.5; // 50% of viewport
  return (
    rect.bottom > windowHeight * threshold &&
    rect.right > windowWidth * threshold
  );
}

function dismissOnboardingHook() {
  const root = document.querySelector("[data-tippy-root]");
  if (!root) return;
  if (isBottomRight(root)) {
    const checkbox = root.querySelector('[type="checkbox"]');
    if (!checkbox.checked) {
      checkbox.checked = true;
      setTimeout(() => {
        root.querySelector("button").click();
      }, 1000);
    }
  }
}

async function cookieSettings() {
  let step = 0;
  const steps = setInterval(() => {
    if (step === 0){
    const cookieBanner = document.querySelector("[id*=onetrust-banner]");
    const cookieSettings = cookieBanner.querySelector('.cookie-setting-link');
    if (!cookieSettings) return;
    cookieSettings.click();
    } else if(step ===1){
    const checkboxes = document.querySelectorAll('input[type="checkbox"]');
    if (checkboxes && checkboxes.length > 0) {
      checkboxes.forEach(checkbox => {
        if (checkbox.getAttribute('aria-checked') === "true") {
          checkbox.click();
        }
      });
    }
  } else if(step===2){
    const savePreferenceButton = [...document.querySelectorAll('[class="save-preference-btn-container"] button')].pop();
    savePreferenceButton.click();
  } else if(step===3){
    clearInterval(steps);
  }
    step++;
  }, 1000);
}

// await cookieSettings();

function clickLastPlaylist() {
  const navBar = [
    ...document.querySelector("nav").querySelectorAll("ul")
  ].pop();
  const playlists = [...navBar.querySelectorAll("li")].filter(li => {
    const p = li.querySelector("p");
    return p && p.id.includes("playlist");
  });

  if (playlists.length === 0) {
    createEmptyPlaylist();
  } else {
    playlists[0].querySelector('[role="button"]').click();
  }
}

function getNumberOfTracks() {
  const playlistTitle = document.querySelector("h1");
  if (!playlistTitle) return;
  playlistTitle.scrollIntoView({
    behavior: "smooth",
    block: "center"
  });
  const entityTitle = document.querySelector('[data-testid="entityTitle"]');
  if (entityTitle) {
    let playlistInfo = entityTitle.nextElementSibling;
    if (playlistInfo) {
      playlistInfo = playlistInfo.lastChild;
      if (playlistInfo) {
        let numberOfTracks = playlistInfo.textContent.match(/([0-9]+) songs/);
        if (numberOfTracks) {
          numberOfTracks = numberOfTracks[1];
          numberOfTracks = parseInt(numberOfTracks);
          return numberOfTracks;
        }
      }
    }
  }
}

function scrollToRandomTrack() {
  const numberOfTracks = getNumberOfTracks();
  const tracklistRows = document.querySelectorAll(
    '[data-testid="tracklist-row"]'
  );
  const numberOfVisibleTracks = tracklistRows.length;
  if (numberOfVisibleTracks < numberOfTracks) {
    randomIndex = Math.floor(Math.random() * numberOfVisibleTracks);
  } else {
    randomIndex = Math.floor(Math.random() * numberOfTracks);
  }
  tracklistRows[randomIndex].scrollIntoView({
    behavior: "smooth",
    block: "center"
  });
}

const INTERVALS = {
  PLAYING_BAR: { min: 0, max: 1 },
  PLAYLIST_BAR: { min: 1, max: 3 },
  SKIP_TRACK: { min: 5, max: 7 },
  RANDOM_TRACK: { min: 9, max: 11 },
  OPEN_NEW_TAB: { min: 12 }
};

async function resumePlayback(attemptCount) {
  const playBarEnabled = playingBarStatus() === "enabled";
  if (playBarEnabled) {
    forcePlay();
  }
  let isStuck = await playbackStuck();
  if (!isStuck) return isStuck;
  if (attemptCount > 1) {
    log(`[${attemptCount}] Trying to resume playback...`, 2);
  }
  if (
    attemptCount >= INTERVALS.PLAYING_BAR.min &&
    attemptCount <= INTERVALS.PLAYING_BAR.max
  ) {
    if (playBarEnabled) {
      handlePlayback(ids.playingBar);
    } else {
      handlePlayback(ids.playlistBar);
    }
  }
  isStuck = await playbackStuck();
  if (!isStuck) return isStuck;
  if (attemptCount > INTERVALS.PLAYLIST_BAR.min) {
    handlePlayback(ids.playlistBar);
  }
  isStuck = await playbackStuck();
  if (!isStuck) return isStuck;
  if (attemptCount > INTERVALS.SKIP_TRACK.min) {
    await skipTrack(false);
  }
  isStuck = await playbackStuck();
  if (!isStuck) return isStuck;
  if (attemptCount > INTERVALS.RANDOM_TRACK.min) {
    await clickRandomTrack();
  } else if (attemptCount > INTERVALS.OPEN_NEW_TAB.min) {
    duplicateTab();
  }
  isStuck = await playbackStuck();
  return isStuck;
}
// async function resumePlayback(attemptCount) {
//   const playBarEnabled = playingBarStatus() === "enabled";
//   if (playBarEnabled) {
//     forcePlay();
//   }

//   let isStuck = await playbackStuck();
//   if (!isStuck) {
//     if (attemptCount > 1) {
//       log(`[${attemptCount}] Playback resumed successfully`, 1);
//     }
//     return;
//   }

//   if (attemptCount > 1) {
//     log(`[${attemptCount}] Trying to resume playback...`, 2);
//   }

//   const actions = [
//     {
//       min: INTERVALS.PLAYING_BAR.min,
//       max: INTERVALS.PLAYING_BAR.max,
//       action: () =>
//         handlePlayback(playBarEnabled ? ids.playingBar : ids.playlistBar)
//     },
//     {
//       min: INTERVALS.PLAYLIST_BAR.min,
//       max: INTERVALS.PLAYLIST_BAR.max,
//       action: () => handlePlayback(ids.playlistBar)
//     },
//     {
//       min: INTERVALS.SKIP_TRACK.min,
//       max: INTERVALS.SKIP_TRACK.max,
//       action: async () => await skipTrack(false)
//     },
//     {
//       min: INTERVALS.RANDOM_TRACK.min,
//       action: async () => await clickRandomTrack()
//     },
//     { min: INTERVALS.OPEN_NEW_TAB.min, action: () => duplicateTab() }
//   ];

//   for (const { min, max, action } of actions) {
//     if (attemptCount >= min && (!max || attemptCount <= max)) {
//       await action();
//       if (!await playbackStuck()) {
//         return;
//       }
//     }
//   }
// }

let everyMinute = 0;
let attemptCount = 0;
let isResumed = false;
let isStuck = true;
let didLog = false;

(async function() {
  const loop = setInterval(async () => {
    everyMinute++;
    // log(everyMinute, 1);
    if (everyMinute > 10) {
      scrollToRandomTrack();
      everyMinute = 0;
    }
    // duplicateTab();
    const location = document.location;

    if (location.host.includes("open.spotify")) {
      try {
        if (!isLoggedIn()) {
          if (!didLog) {
            log("Not logged in", 1);
            didLog = true;
          }
          return;
        }
        // > PLAYLIST
        if (location.pathname.includes("/playlist/")) {
          repeatShuffleUnmute();
          closeNowPlayingView();
          collapseLibrary();
          dismissOnboardingHook();
          saveToLibrary();
          await skipTrack(true);
          isStuck = await resumePlayback(attemptCount);

          if (!isStuck) {
            if (!isResumed) {
              log("Playback resumed", 1);
              isResumed = true;
            }
            attemptCount = 0;
            return;
          }

          isResumed = false;
          attemptCount++;
        } else {
          clickLastPlaylist();
          // const playlists = getPlaylists();
          // if (playlists.length === 0) {
          //   createEmptyPlaylist();
          // }
        }
        // < PLAYLIST
      } catch (error) {
        if (attemptCount > 3 && document.body.childElementCount === 1) {
          document.location.reload(true);
        }
        log(error, 3);
      }
    }
  }, 2000);
})();
