function colorProgressBar(h, s = 100, l = 50) {
  const progressBar = document.querySelector('[data-testid="progress-bar" i]');
  if (!progressBar) {
    return;
  }
  progressBar.style.setProperty("--fg-color", `hsl(${h}, ${s}%, ${l}%)`);
}

function progressBarStatus() {
  const playbackProgressBar = document.querySelector(
    '[data-testid="playback-progressbar" i]'
  );
  if (!playbackProgressBar) {
    return false;
  }
  return playbackProgressBar.children[1].style.cssText.match("[0-9.]+")[0];
}

function skipTrack(withConditions = true) {
  if (
    document.title.toLowerCase().includes("advertisement") ||
    !document.querySelector("footer")
  ) {
    return;
  }

  const skipButton = document.querySelector(
    '[data-testid="control-button-skip-forward" i]'
  );

  const toSecs = (t) => t.split(":").reduce((m, s) => m * 60 + +s);
  const [playbackPosition, playbackDuration] = [
    "playback-position",
    "playback-duration"
  ].map((id) =>
    toSecs(document.querySelector(`[data-testid="${id}"]`).innerText)
  );

  if (withConditions) {
    const contextItemInfoArtist = document.querySelector(
      '[data-testid="context-item-info-artist" i]'
    );
    if(!contextItemInfoArtist && !contextItemInfoArtist.innerText) {
      return;
    }
    const base64String = "d2VzdGdhcmR8bG9ja3dvb2Q=";
    const decodedStr = atob(base64String);
    const regex = new RegExp(decodedStr, "i");
    if (contextItemInfoArtist.innerText.match(regex)) {
      colorProgressBar(100);
      return;
    }

    const progressBarStatusValue = progressBarStatus();
    if (!progressBarStatusValue) {
      return;
    }

    // Calculate the percentage of the track that has been played
    const playbackPercentage = (playbackPosition / playbackDuration) * 100;

    // Generate a random value between 5% and 80%
    const randomValue = Math.random() * 75 + 5;

    const hue = (1 - progressBarStatusValue / randomValue) * 120;
    colorProgressBar(hue);

    // Skip the track if the playback percentage is greater than the random value
    if (playbackPercentage > randomValue) {
      skipButton.click();
      const contextInfo = [
        ...new Set(
          [
            ...document.querySelectorAll('[data-testid*="context-item-info" i]')
          ].map((e) => e.innerText)
        )
      ].join(" by ");
      log(`${contextInfo} [skipped after ${playbackPosition} seconds.]`);
    }
    return;
  }
  skipButton.click();
}


const loop = setInterval(() => {
    skipTrack();
}, 1000);