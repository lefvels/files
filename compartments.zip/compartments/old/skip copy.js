function updateProgressBar(h, s = 100, l = 50) {
  const progressBar = document.querySelector('[data-testid="progress-bar" i]');
  const playbackProgressBar = document.querySelector(
    '[data-testid="playback-progressbar" i]'
  );

  if (!progressBar || !playbackProgressBar) {
    return false;
  }

  progressBar.style.setProperty("--fg-color", `hsl(${h}, ${s}%, ${l}%)`);
  return playbackProgressBar.children[1].style.cssText.match("[0-9.]+")[0];
}

function skipTrack(withConditions = true) {
    // Do not continue if advertisement is playing
  if (
    document.title.toLowerCase().includes("advertisement") ||
    !document.querySelector("footer")
  ) {
    return;
  }
  // Define the skip button
  const skipButton = document.querySelector(
    '[data-testid="control-button-skip-forward" i]'
  );

  // Get playback position and duration in seconds
  const toSecs = (t) => t.split(":").reduce((m, s) => m * 60 + +s);
  const [playbackPositionNode, playbackDurationNode] =
    document.querySelectorAll('[data-testid*="playback-" i]');
  const playbackPosition = toSecs(playbackPositionNode.innerText);
  const playbackDuration = toSecs(playbackDurationNode.innerText);

  if (withConditions) {
    const contextItemInfoArtist = document.querySelector(
      '[data-testid="context-item-info-artist" i]'
    );

    const base64String = "d2VzdGdhcmR8bG9ja3dvb2Q=";
    const decodedStr = atob(base64String);
    const regex = new RegExp(decodedStr, "i");

    // Do not skip if the context item info artist matches the regex
    if (contextItemInfoArtist?.innerText?.match(regex)) {
      updateProgressBar(100);
      return;
    }

    // Skip if the playback position is greater than 5% of the track duration
    const progressBarStatusValue = updateProgressBar();
    if (!progressBarStatusValue) {
      return;
    }

    // Calculate the percentage of the track that has been played
    const playbackPercentage = (playbackPosition / playbackDuration) * 100;

    // Generate a random value between 5% and 80%
    const randomValue = Math.random() * 75 + 5;

    // Skip the track if the playback percentage is greater than the random value
    if (playbackPercentage > randomValue) {
      skipButton.click();
      const contextInfo = [
        ...new Set(
          [
            ...document.querySelectorAll('[data-testid*="context-item-info" i]')
          ].map((e) => e.innerText)
        )
      ].join(" by ");
      log(`${contextInfo} [skipped after ${playbackPosition} seconds.]`);
    }
    return;
  }
  skipButton.click();
}
