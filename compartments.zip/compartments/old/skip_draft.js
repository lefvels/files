try {
  clearInterval(loop);
} catch (e) {}

function colorProgressBar(h, s = 100, l = 50) {
  const progressBar = document.querySelector('[data-testid="progress-bar" i]');
  if (!progressBar) {
    return;
  }
  progressBar.style.setProperty("--fg-color", `hsl(${h}, ${s}%, ${l}%)`);
}

function playbackProgress() {
  try {
    const progressBar = document.querySelector(
      "[data-testid=playback-progressbar] [data-testid=progress-bar]"
    );
    const match = progressBar.style.cssText.match(/(\d+(\.\d+)?)%/);
    const percent = parseFloat(match[1]);
    colorProgressBar(percent);
    return percent;
  } catch (e) {
    return false;
  }
}


function skipTrack(delay = true) {
  if (
    document.title === "Spotify – Advertisement" ||
    !document.querySelector("footer")
  ) {
    return;
  }

  const skipButton = document.querySelector(
    '[data-testid="control-button-skip-forward" i]'
  );

  if (delay) {
    const artistInfo = document.querySelector(
      '[data-testid="context-item-info-artist" i]'
    );

    const toSeconds = (t) => t.split(":").reduce((m, s) => m * 60 + +s);
    const [playbackPosition, playbackDuration] = ["playback-position", "playback-duration"].map(
      (id) => toSeconds(document.querySelector(`[data-testid="${id}"]`).innerText)
    );
    const playbackProgress = (position / duration) * 100;

    const base64String = "d2VzdGdhcmR8bG9ja3dvb2Q=";
    const decodedStr = atob(base64String);
    const regex = new RegExp(decodedStr, "i");

    if (artist?.innerText?.match(regex)) {
      colorProgressBar(100);
      return;
    }

    const progress = progressBarStatus();
    if (!progress) {
      return;
    }
    console.info(`progressPercentage: ${progress}`);
    const randomValue = Math.random() * 75 + 5;
    const hue = (1 - progress / randomValue) * 120;
    colorProgressBar(hue);
    // console.info(`progressPercentage: ${progress}, position: ${position}, randomValue: ${randomValue}`);

    if (position > 30 && progress > randomValue) {
      skipButton.click();
      const trackInfo = [
        ...new Set(
          [
            ...document.querySelectorAll('[data-testid*="context-item-info" i]')
          ].map((e) => e.innerText)
        )
      ].join(" by ");
      console.log(`${trackInfo} [skipped after ${position} seconds.]`);
    }
    return;
  }
  skipButton.click();
}

const loop = setInterval(() => {
  skipTrack();
}, 1000);
