/*
## Constants
*/
const hostsToClear = ["open.spotify.com"];
const tabMap = new Map();

/*
## Disable non-proxied UDP, for privacy
*/
chrome.privacy.network.webRTCIPHandlingPolicy.set({
  value: "disable_non_proxied_udp"
});

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ hosts: hostsToClear });
});

/*
## Remove cookies for specified hosts
*/
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== "complete") return;

  const hostname = new URL(tab.url).hostname;
  if (hostsToClear.includes(hostname)) {
    chrome.cookies.getAll({ domain: hostname }, cookies => {
      cookies.forEach(cookie => {
        chrome.cookies.remove({ url: tab.url, name: cookie.name });
      });
    });
  }
});

/*
## Prevent browser to close: if last tab is closed, open a new window
*/
chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  if (removeInfo.isWindowClosing) {
    chrome.tabs.query({}, tabs => {
      if (tabs.length === 1) {
        chrome.tabs.create({});
      }
    });
  }
});

/*
## Zoom to 30%, for better viewing
*/
chrome.tabs.onZoomChange.addListener(({ tabId, newZoomFactor }) => {
  chrome.tabs.get(tabId, tab => {
    const hostname = new URL(tab.url).hostname;
    if (hostsToClear.includes(hostname) && newZoomFactor > 0.3) {
      chrome.tabs.setZoom(tabId, 0.3);
    }
  });
});

/*
## Duplicate active tab
*/
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.message === "duplicateTab") {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      chrome.tabs.duplicate(tabs[0].id, function() {
        sendResponse({ status: "success" });
      });
    });
    return true; // return true to asynchronously respond
  }
});

/*
## Check for and remove duplicate tabs
*/
chrome.runtime.onMessage.addListener(({ url }, { tab }) => {
  for (let [id, u] of tabMap) {
    if (u === url && id !== tab.id) {
      chrome.tabs.remove(id);
      tabMap.delete(id);
      break;
    }
  }
  tabMap.set(tab.id, url);
});
chrome.tabs.onRemoved.addListener(id => {
  tabMap.delete(id);
});

/*
## Check for Spotify tab and create if not exist
*/
function checkForSpotifyTab() {
  chrome.windows.getAll({ populate: true }, windows => {
    const tabs = windows.flatMap(window => window.tabs);
    const hasSpotifyTab = tabs.some(tab => hostsToClear.includes(new URL(tab.url).hostname));

    if (!hasSpotifyTab) {
      chrome.tabs.create({ url: "https://open.spotify.com", active: true });
    }
    setTimeout(checkForSpotifyTab, 2000);
  });
}
checkForSpotifyTab();

/*
## Mute and reload existing tabs
*/
function handleExistingTabs() {
  chrome.tabs.query({}, tabs => {
    tabs.forEach(tab => {
      const hostname = new URL(tab.url).hostname;
      if (hostsToClear.includes(hostname)) {
        chrome.tabs.update(tab.id, { muted: true });
        chrome.tabs.reload(tab.id);
      }
    });
  });
}
handleExistingTabs();
chrome.tabs.onUpdated.addListener((tabId, { status }, tab) => {
  if (status === "complete") {
    const hostname = new URL(tab.url).hostname;
    if (hostsToClear.includes(hostname)) {
      chrome.tabs.update(tabId, { muted: true });
    }
  }
});
chrome.runtime.onInstalled.addListener(handleExistingTabs);