// background.js

chrome.privacy.network.webRTCIPHandlingPolicy.set({
  value: "disable_non_proxied_udp"
});

chrome.action.onClicked.addListener(execScript);

async function execScript() {
  const tabId = await getTabId();
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    files: ["execute.js"]
  });
}

async function getTabId() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs.length > 0 ? tabs[0].id : null;
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.type === "toggleExtension") {
    chrome.management.setEnabled(request.id, request.enable);
  }
});

chrome.action.onClicked.addListener(tab => {
  chrome.tabs.sendMessage(tab.id, { message: "duplicateTab" });
});

// chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
//   if (request.message === "duplicateTab") {
//     chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
//       let originalTabId = tabs[0].id;

//       chrome.tabs.duplicate(originalTabId, duplicatedTab => {
//         chrome.tabs.remove(originalTabId, () => {
//           // Send response to acknowledge
//           sendResponse({
//             status: "tab duplicated and original removed successfully!",
//             originalTabId: originalTabId,
//             duplicatedTabId: duplicatedTab.id
//           });
//         });
//       });
//       // Return true to signal async response
//       return true;
//     });
//     // Return true to signal async response
//     return true;
//   }
// });

// checkForTab();

function checkForTab() {
  chrome.tabs.query({}, tabs => {
    const match = tabs.some(tab => tab.url.includes("open.spotify.com"));
    if (!match) {
      chrome.tabs.create({ url: `https://open.spotify.com` });
    }
    setTimeout(checkForTab, 5000);
  });
}

// // Store tabs in an array to easily find duplicates
// const tabs = [];

// // Listen for tab updates
// chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
//   // Only check for duplicates on loading complete
//   if (changeInfo.status !== "complete") return;

//   // Check if tab already exists in array
//   const duplicate = tabs.find(t => t.url === tab.url);

//   if (duplicate) {
//     // If duplicate found, remove from array
//     tabs.splice(tabs.indexOf(duplicate), 1);

//     // Close the duplicate tab
//   //  chrome.tabs.remove(tabId);
//   } else {
//     // If new unique tab, add to array
//     tabs.push(tab);
//   }
// });

// // Listen for tabs being removed
// chrome.tabs.onRemoved.addListener(tabId => {
//   // Find and remove tab from array
//   const index = tabs.findIndex(tab => tab.id === tabId);
//   if (index !== -1) {
//     tabs.splice(index, 1);
//   }
// });

// Zoom handler
chrome.tabs.onZoomChange.addListener(zoomChangeInfo => {
  const { tabId, newZoomFactor } = zoomChangeInfo;
  chrome.tabs.get(tabId, tab => {
    const url = new URL(tab.url);
    if (url.hostname === "open.spotify.com" && newZoomFactor > 0.93) {
      chrome.tabs.setZoom(tabId, 0.93);
    }
  });
});

const mutedHostnames = ["spotify.com", "open.spotify.com"];

// Mute all existing tabs on load
muteExistingTabs();

// Mute any new tabs on update
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete") {
    muteTab(tab);
  }
});

function muteExistingTabs() {
  chrome.tabs.query({}, tabs => {
    for (let tab of tabs) {
      muteTab(tab);
    }
  });
}

function muteTab(tab) {
  const hostname = new URL(tab.url).hostname;
  if (mutedHostnames.includes(hostname)) {
    chrome.tabs.update(tab.id, { muted: true });
  }
}

chrome.webNavigation.onDOMContentLoaded.addListener(() => {
  chrome.scripting.executeScript({
    func: clearBrowserData
  });
});

// const tabs = {}; // track open tabs

// chrome.tabs.onCreated.addListener(tab => {
//   if (tabs[tab.url]) {
//     chrome.tabs.remove(tab.id);
//   } else {
//     tabs[tab.url] = tab.id;
//   }
// });

// chrome.tabs.onRemoved.addListener(tabId => {
//   const url = Object.keys(tabs).find(url => tabs[url] === tabId);
//   delete tabs[url];
// });
