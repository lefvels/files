
const muteButton = document.querySelector(
  '[data-testid="volume-bar-toggle-mute-button" i]'
);
const repeatButton = document.querySelector(
  '[data-testid="control-button-repeat" i]'
);
const shuffleButton = document.querySelector(
  '[data-testid="control-button-shuffle" i]'
);
const currentVolume = document.querySelector("[class*=volume-bar] input");

const closePanelButton = document.querySelector(
  '[data-testid="PanelHeader_CloseButton"] button'
);


// all selectors:
const ids = {
  playingBar: ["now-playing-bar", "control-button-playpause"],
  playlistBar: ["action-bar-row", "play-button"],
  loginButton: ["[data-testid='login-button' i]"],
  repeatButton : ["[data-testid='control-button-repeat' i]"],
  shuffleButton : ["[data-testid='control-button-shuffle' i]"],
  muteButton : ["[data-testid='control-button-mute' i]"],
  playButton : ["[aria-label*='play' i]"],
  playlistPage : [ "[data-testid='playlist-page' i] [role='grid']"],
  progressBar: ["[data-testid='progress-bar' i]"],
  artistInfo : ["[data-testid='context-item-info-artist' i]"],
  skipButton : ["[data-testid='control-button-skip-forward' i]"],
  currentVolume : ["[data-testid='volume-bar' i] input"],
  closePanelButton : ["[data-testid='PanelHeader_CloseButton' i] button"]

};