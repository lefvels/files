/*
## disable non-proxied UDP, for privacy
*/
chrome.privacy.network.webRTCIPHandlingPolicy.set({
  value: "disable_non_proxied_udp"
});

const hostsToClear = ["open.spotify.com"];
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ hosts: hostsToClear });
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url.includes(hostsToClear)) {
    chrome.cookies.getAll({ domain: tab.url }, cookies => {
      cookies.forEach(cookie => {
        chrome.cookies.remove({ url: tab.url, name: cookie.name });
      });
    });
  }
});


chrome.tabs.onRemoved.addListener((tabId, removeInfo) => {
  if (removeInfo.isWindowClosing) {
    chrome.tabs.query({currentWindow: true}, tabs => {
      if (tabs.length === 1) {
        chrome.tabs.create({});
      }
    });
  }
});


/*
## zoom to 30%, for better viewing
*/
chrome.tabs.onZoomChange.addListener(({ tabId, newZoomFactor }) => {
  chrome.tabs.get(tabId, tab => {
    if (
      new URL(tab.url).hostname === "open.spotify.com" &&
      newZoomFactor > 0.3
    ) {
      chrome.tabs.setZoom(tabId, 0.3);
    }
  });
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.message === "duplicateTab") {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      chrome.tabs.duplicate(tabs[0].id, function() {
        sendResponse({ status: "success" });
      });
    });
    return true; // return true to asynchronously respond
  }
});

/*
## check for duplicate tabs, if found, remove
*/
const tabMap = new Map();
chrome.runtime.onMessage.addListener(({ url }, { tab }) => {
  for (let [id, u] of tabMap) {
    if (u === url && id !== tab.id) {
      chrome.tabs.remove(id);
      tabMap.delete(id);
      break;
    }
  }
  tabMap.set(tab.id, url);
});

chrome.tabs.onRemoved.addListener(id => {
  tabMap.delete(id);
});


// function checkForSpotifyTab() {
//   chrome.tabs.query({}, tabs => {
//     const hasSpotifyTab = tabs.some(tab =>
//       tab.url.includes("open.spotify.com")
//     );
//     if (!hasSpotifyTab) {
//       chrome.tabs.create({ url: "https://open.spotify.com", active: true });
//     }
//     setTimeout(checkForSpotifyTab, 2000);
  
//   });
// }
// function checkForSpotifyTab() {
//   chrome.windows.getAll({ populate: true }, windows => {
//     const tabs = windows.flatMap(window => window.tabs);
//     const hasSpotifyTab = tabs.some(tab => tab.url.includes("open.spotify.com"));

//     if (!hasSpotifyTab) {
//       chrome.tabs.create({ url: "https://open.spotify.com", active: true });
//     }

//     setTimeout(checkForSpotifyTab, 2000);
//   });
// }

function checkForSpotifyTab() {
  chrome.windows.getAll({ populate: true }, windows => {
    const tabs = windows.flatMap(window => window.tabs);
    // const ignoreTabs = ["accounts.spotify.com", "challenge.spotify.com"];
    
    const hasSpotifyTab = tabs.some(tab => {
      const url = new URL(tab.url);
      return url.hostname.includes("spotify.com")
    });

    if (!hasSpotifyTab) {
      chrome.tabs.create({ url: "https://open.spotify.com", active: true });
    }

    setTimeout(checkForSpotifyTab, 2000);
  });
}
checkForSpotifyTab();

/*
## mute existing tabs
*/

muteExistingTabs();
chrome.tabs.onUpdated.addListener(muteIfComplete);
chrome.runtime.onInstalled.addListener(reloadExistingTabs);

function muteExistingTabs() {
  chrome.tabs.query({}, tabs => tabs.forEach(muteTab));
}

function muteIfComplete(tabId, { status }, tab) {
  if (status === "complete") muteTab(tab);
}

function muteTab(tab) {
  const hostname = new URL(tab.url).hostname;
  if (["spotify.com", "open.spotify.com"].includes(hostname)) {
    chrome.tabs.update(tab.id, { muted: true, active: true });
  }
}




function reloadExistingTabs() {
  chrome.tabs.query({}, tabs =>
    tabs.forEach(tab => {
      const hostname = new URL(tab.url).hostname;
      if (hostname === "open.spotify.com") chrome.tabs.reload(tab.id);
    })
  );
}
