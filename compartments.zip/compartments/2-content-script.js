const VERBOSE = false;

// Custom function to log messages to the console
function log(message, type = 1) {
  let style;
  let symbolStyle;
  let symbol;

  if (type === 1) {
    style = "color: lightblue";
    symbolStyle = "color: lightblue; font-size: 15px;";
    symbol = "\u2139";
  } else if (type === 2) {
    style = "color: orange;";
    symbolStyle = "color: orange; font-size: 20px; font-weight: bold";
    symbol = "\u26A0";
  } else if (type === 3) {
    style = "color: red;";
    symbolStyle = "color: red; font-size: 20px; font-weight: bold";
    symbol = "\u2715";
  }
  console.info(`%c${symbol} %c${message}`, symbolStyle, style);
}

const extensions = {
  buster: "mpbjkejclgfgadiemmefgebjfooflfhl",
  nopecha: "dknlfmjaanfblgfdfebhijalfmhmjjjo",
  webgl: "olnbjpaejebpnokblkepbphhembdicik",
  spoof: "facgnnelgcipeopfbjcajpaibhhdjgcp",
  signup: "nhdbgbhddngilnoffcoglmjfmjhkpapj"
};

const ids = {
  playingBar: ["now-playing-bar", "control-button-playpause"],
  playlistBar: ["action-bar-row", "play-button"],
  loginButton: ["[data-testid='login-button' i]"],
  repeatButton: ["[data-testid='control-button-repeat' i]"],
  shuffleButton: ["[data-testid='control-button-shuffle' i]"],
  muteButton: ["[data-testid='control-button-mute' i]"],
  playButton: ["[aria-label*='play' i]"],
  playlistPage: ["[data-testid='playlist-page' i] [role='grid']"],
  progressBar: ["[data-testid='progress-bar' i]"],
  volumeBar: ["[class*='volume-bar' i] input"],
  artistInfo: ["[data-testid='context-item-info-artist' i]"],
  skipButton: ["[data-testid='control-button-skip-forward' i]"],
  currentVolume: ["[data-testid='volume-bar' i] input"],
  closePanelButton: ["[data-testid='panelheader_close' i] button"],
  contextItemInfo: ["[data-testid*='context-item-info' i]"],
  leftSidebarFooter: ["[data-testid='left-sidebar-footer' i]"],
  saveToLibrary: ["[class*='control-button-heart' i]"],
  nowPlayingBar: ["[data-testid='now-playing-bar']"]
};

const toggleExtension = (id, enable) => {
  try {
    chrome.runtime.sendMessage({
      type: "toggleExtension",
      id: id,
      enable: enable
    });
  } catch (e) {
    // log(`extension ${id} not found`, 3);
  }
};

toggleExtension(extensions.webgl, true);
toggleExtension(extensions.spoof, true);

function getTrackInfo() {
  return [
    ...new Set(
      [
        ...document.querySelectorAll(ids.contextItemInfo) // '[data-testid*="context-item-info" i]'
      ].map(e => e.innerText)
    )
  ].join(" — ");
}

function getPlaylists() {
  return (playlists = ["playlist", "folder"]
    .map(i => {
      return document.body.querySelector(
        `[aria-labelledby*=':${i}'] [role=button]`
      );
    })
    .filter(i => i !== null));
}

function advertisementCheck() {
  return document.title.toLowerCase().includes("advertisement");
}

function repeatShuffleUnmute() {
  // const muteButton = document.querySelector(ids.muteButton); // '[data-testid="volume-bar-toggle-mute-button" i]'
  const repeatButton = document.querySelector(ids.repeatButton); // '[data-testid="control-button-repeat" i]'
  const shuffleButton = document.querySelector(ids.shuffleButton); // '[data-testid="control-button-shuffle" i]'
  const currentVolume = document.querySelector(ids.volumeBar); // "[class*=volume-bar] input
  const closePanelButton = document.querySelector(ids.closePanelButton); // '[data-testid="PanelHeader_CloseButton"] button'

  if (!advertisementCheck()) {
    if (repeatButton && repeatButton.ariaChecked !== "true")
      repeatButton.click();
    if (shuffleButton && shuffleButton.ariaChecked !== "true")
      shuffleButton.click();
    // if (currentVolume && parseInt(currentVolume.value) === 0) {
    //   muteButton.click();
    // }
    if (closePanelButton) {
      closePanelButton.click();
    }
  }
}

// Helper function to set color of progress bar
function colorProgressBar(h, s = 100, l = 50) {
  if (isNaN(h) | (h < 0) | (h > 100)) {
    document.cookie = `hue=0;path=/`;
  }
  const progressBar = document.querySelector('[data-testid="progress-bar" i]'); // ok
  let hue = document.cookie.match(/hue=([0-9]+)/);
  if (hue) {
    hue = parseInt(hue[0].replace("hue=", ""));
    if (h > hue) {
      return;
    }
  }
  progressBar.style.setProperty("--fg-color", `hsl(${h}, ${s}%, ${l}%)`);
  document.cookie = `hue=${h};path=/`;
}

// Get artist name
function getArtistName() {
  const artistNameElement = document.querySelector(ids.artistInfo);
  if (!artistNameElement || !artistNameElement.textContent) {
    return null;
  }
  return artistNameElement.textContent.trim();
}

// Decode blacklist
function decodeBlacklist() {
  const base64String = "d2VzdGdhcmR8bG9ja3dvb2Q=";
  return atob(base64String).split("|");
}

// Check if artist is in blacklist
function isListedArtist() {
  if (advertisementCheck()) {
    return false;
  }
  let artistName = getArtistName();
  const blacklist = decodeBlacklist();
  if (artistName) {
    artistName = artistName.toLowerCase();
    return blacklist.some(artist => artistName.includes(artist));
  }
  return false;
}

// Main skip artist logic
function skipArtist() {
  if (advertisementCheck()) {
    return true;
  }
  const artistName = getArtistName();
  if (!artistName) {
    return true;
  }
  if (isListedArtist()) {
    return false;
  } else {
    return false;
  }
}

function saveToLibrary(minHours = 0) {
  if (advertisementCheck()) {
    return;
  }
  const minSeconds = minHours * 60 * 60;
  let saveProbability = 1 / minSeconds * 5;
  if (!isListedArtist()) {
    saveProbability /= 2;
  }
  let heartButton = document.querySelector(ids.nowPlayingBar);
  if (!heartButton) {
    return;
  }
  heartButton = heartButton.querySelector(ids.cot);
  if (!heartButton) {
    return;
  }
  const hearted = heartButton.getAttribute("aria-checked");
  if (!hearted) {
    if (Math.random() < saveProbability) {
      heartButton.click();
      const trackInfo = getTrackInfo();
      log(`Added to library: ${trackInfo}`, 1);
    }
  }
}

// Helper function to convert mm:ss to seconds
const toSeconds = id => {
  let time = document.querySelector(`[data-testid='playback-${id}']`);
  if (!time) {
    return;
  }
  time = time.innerText;
  time = time.split(":");
  return time.reduce((total, part) => total * 60 + Number(part));
};

// Helper function to get playback values
function getPlayback(type) {
  const position = toSeconds("position");
  const duration = toSeconds("duration");
  const percentage = position / duration * 100;

  if (!position || !duration) {
    return 0;
  }

  switch (type) {
    case "positionInSeconds":
      return position;
    case "durationInSeconds":
      return duration;
    case "positionInPercentage":
      return percentage;
    default:
      return 0;
  }
}

// Helper function to skip track
function skipTrack(withConditions = false) {
  if (!skipArtist()) {
    colorProgressBar(100);
    return;
  }

  const skipButton = document.querySelector(ids.skipButton); // '[data-testid="control-button-skip-forward" i]'
  if (!skipButton) return;
  const position = getPlayback("positionInSeconds");
  const percentage = getPlayback("positionInPercentage");
  const duration = getPlayback("durationInSeconds");
  const critical = Math.random() * 25 + 50;
  const hue = (1 - position / (duration * (critical / 100))) * 100;
  colorProgressBar(hue);

  if (withConditions) {
    document.title = `[${(critical - percentage).toFixed(
      1
    )}%] ${document.title.replace(/\[[0-9.]+%\]/g, "").trim()}`;
    if (position > 30 && percentage > critical) {
      const remaining = duration - position;
      const trackInfo = getTrackInfo();
      log(
        `${trackInfo} [skiped at ${percentage.toFixed(
          2
        )}%, with ${remaining} seconds remaining]`
      );
      skipButton.click();
    }
  } else {
    skipButton.click();
  }
}

async function simulateRightClickOnElement(selector) {
  const targetElement = document.querySelector(selector);
  const targetElementRect = targetElement.getBoundingClientRect();

  const clickPositionX = targetElementRect.left + targetElementRect.width / 2;
  const clickPositionY = targetElementRect.top;

  const simulatedRightClickEvent = new MouseEvent("contextmenu", {
    bubbles: true,
    cancelable: true,
    view: window,
    button: 2,
    buttons: 2,
    clientX: clickPositionX,
    clientY: clickPositionY
  });

  targetElement.dispatchEvent(simulatedRightClickEvent);
}

async function createEmptyPlaylist() {
  await simulateRightClickOnElement("[class*=content-glue]");
  const waitForTippy = setInterval(() => {
    let tippy = document.querySelector("[data-tippy-root] button");
    if (!tippy) return;
    tippy.click();
    clearInterval(waitForTippy);
  }, 1000);
}

function clickCloseButton() {
  const dialog = document.querySelector("[class*='dialog']");
  if (!dialog) return;
  let closeButtons = [...document.querySelectorAll("button")];
  if (!closeButtons) return;
  closeButtons.filter(i => i.innerText.toLowerCase().includes("close")).shift();
}

// Helper function to check if the displayed values match the progress bar position
function playbackCheck() {
  const playbackReference = getPlayback("positionInPercentage");
  const progressBar = document.querySelector('[data-testid="progress-bar" i]'); // ok
  if (!progressBar) {
    return;
  }
  const match = progressBar.style.cssText.match(/(\d+(\.\d+)?)%/);
  const percent = parseInt(match[1]);
  return percent === parseInt(playbackReference);
}

// Helper function to check if playback is stuck
async function playbackStuck() {
  // const duration = getPlayback("durationInSeconds");
  const t1 = getPlayback("positionInSeconds");
  await new Promise(resolve => setTimeout(resolve, 1000));
  const t2 = getPlayback("positionInSeconds");
  if (t2 === t1) {
    return true;
  }
  return false;
}

// Helper function to click on random track
async function clickRandomTrack() {
  const playlistPage = document.querySelector(
    "[data-testid=playlist-page] [role=grid]" // ok
  );

  if (!playlistPage) {
    log("Playlist page not found", 2);
    return;
  }

  const tracks = playlistPage.querySelectorAll('[aria-label*="play" i]'); // ok
  if (!tracks.length) {
    return;
  }

  const ind = Math.floor(Math.random() * tracks.length);
  const track = tracks[ind];

  scrollTo(track);
  try {
    scrollTo(tracks[ind - 2]);
  } catch (e) {}

  await new Promise(resolve => setTimeout(resolve, 300));
  track.dispatchEvent(
    new MouseEvent("dblclick", {
      bubbles: true,
      cancelable: true,
      view: window
    })
  );
}

function handlePlayback(id, returnStatus = false) {
  let play = document.querySelector(`[data-testid="${id[0]}"]`);
  if (!play) return;
  play = play.querySelector(`[data-testid="${id[1]}"]`);
  const isPaused =
    play.querySelector("svg path").outerHTML.match(/z/g).length === 1;
  if (returnStatus) {
    return isPaused ? "paused" : "playing";
  }
  if (isPaused) {
    play.click();
  }
}

function duplicateTab() {
  chrome.runtime.sendMessage({ message: "duplicateTab" }, response => {
    if (chrome.runtime.lastError) {
      console.error(chrome.runtime.lastError);
    } else {
      console.log("Response from background page:", response);
    }
  });
}

function isLoggedIn() {
  const x = document.querySelector(ids.loginButton) !== null;
  if (x) {
    log("Not logged in", 1);
    toggleExtension(extensions.signup, x);
    toggleExtension(extensions.nopecha, x);
    toggleExtension(extensions.buster, x);
    return false;
  }
  return true;
}

function nowPlayingBarIsDisabled() {
  document
    .querySelector("[data-testid=now-playing-bar]")
    .innerHTML.match(/disabled/g)
    ? true
    : false;
}

function forcePlay() {
  const playlistBar = handlePlayback(ids.playlistBar, true);
  const playingBar = handlePlayback(ids.playingBar, true);
  if (playingBar !== playlistBar) {
    log("Playlist changed", 1);
    handlePlayback(ids.playlistBar, false);
  }
}

function closeNowPlayingView() {
  let nowPlayingView = document.querySelector(ids.nowPlayingBar);
  if (!nowPlayingView) return;
  nowPlayingView = nowPlayingView.querySelector(
    "[data-testid='control-button-npv']"
  );
  if (nowPlayingView && nowPlayingView.getAttribute("data-active") === "true") {
    nowPlayingView.click();
  }
}

async function resumePlayback(i) {
  const stuck = await playbackStuck();
  const playBarDisabled = nowPlayingBarIsDisabled();
  if (!stuck && !playBarDisabled) {
    forcePlay();
    return stuck;
  }
  log(`[${i}] Trying to resume playback...`, 2);
  if (i >= 0 && i <= 1) {
    if (!playBarDisabled) {
      handlePlayback(ids.playingBar);
    } else {
      handlePlayback(ids.playlistBar);
    }
  } else if (i > 1 && i <= 5) {
    handlePlayback(ids.playlistBar);
  } else if (i > 5 && i <= 10) {
    await skipTrack(false);
  } else if (i > 10 && i <= 15) {
    await clickRandomTrack();
  } else if (i > 15) {
    duplicateTab();
  }
  return stuck;
}

let i = 0;
let resumed = false;
let stuck = true;
const loop = setInterval(async () => {
  const l = document.location;
  if (l.host.includes("open.spotify")) {
    // > PLAYLIST
    if (!isLoggedIn()) {
      document
        .querySelector("[data-testid='login-button']")
        .previousSibling.click();
    }

    if (isLoggedIn() && l.pathname.includes("/playlist/")) {
      repeatShuffleUnmute();
      closeNowPlayingView();
      saveToLibrary();
      await skipTrack(true);
      stuck = await resumePlayback(i);

      if (!stuck) {
        if (!resumed) {
          log("Playback resumed", 1);
          resumed = true;
        }
        i = 0;
        return;
      }

      if (stuck && advertisementCheck()) {
        document.location.reload(true);
      }

      resumed = false;
      i++;
    }
    // < PLAYLIST
  }
}, 1000);
