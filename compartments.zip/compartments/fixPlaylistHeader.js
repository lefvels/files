const playlistImage = document.querySelector('[data-testid="playlist-image"]')
  .parentElement;

const h1Height = document.querySelector("h1").parentElement.offsetHeight;
playlistImage.style.width = h1Height + "px";
playlistImage.style.height = h1Height + "px";
playlistImage.style.justifyContent = "center";
playlistImage.style.alignItems = "center";
playlistImage.style.alignSelf = "center";

let firstChildOfSection = document.querySelector("section").firstChild;
firstChildOfSection.removeAttribute("class");

firstChildOfSection.style.display = "flex";
const topbarHeight = document.querySelector('[data-testid="topbar"]')
  .offsetHeight; // '64px', not '64px;'
firstChildOfSection.style.padding = topbarHeight + "px"; // should work now
firstChildOfSection.style.paddingLeft = topbarHeight / 2 + "px"; // should work now

function cleanTopBar() {
  const topbar = document.querySelector('[data-testid="topbar"]');
  const upgradeButton = topbar.querySelector('[data-testid="upgrade-button"]');
  const downloadLink = topbar.querySelector("[href*=download]");
  const notificationButton = topbar.querySelector(
    '[class*="encore-over-media-set"]'
  );

  if (upgradeButton) {
    upgradeButton.remove();
  }

  if (downloadLink) {
    downloadLink.remove();
  }

  if (notificationButton) {
    notificationButton.remove();
  }
}
