`%>%` <- dplyr::`%>%`
report_performance_color <- function(.fit) {
  r <- suppressMessages(report::report_performance(.fit))
  unique(r) %>%
    purrr::map(~ strsplit(., "\\. ")) %>%
    unlist() %>%
    unique() %>%
    unlist() %>%
    purrr::map_chr(~ ifelse(grepl("\\.$", .), ., paste0(., "."))) %>%
    purrr::map_chr(~ stringr::str_replace_all(., c(
      "satisfactory" = crayon::green("satisfactory"),
      "poor" = crayon::red("poor"), "good" = crayon::green("good"),
      "significantly different" = crayon::green("significantly different")
    ))) %>%
    purrr::reduce(paste, sep = "\n")
}

p_ind <- function(.df) {
  replace_p_value <- function(x) {
    if (x <= 0.001) {
      return("***")
    } else if (x <= 0.01) {
      return("**")
    } else if (x <= 0.05) {
      return("*")
    } else {
      return("")
    }
  }
  return(sapply(.df, replace_p_value))
}

comp_ses <- function(fit) {
  lavaan::parameterEstimates(fit,
    pvalue = TRUE,
    output = "data.frame", standardized = TRUE
  ) %>%
    dplyr::filter(op == "~") %>%
    dplyr::mutate(effect = paste(lhs, op, rhs)) %>%
    dplyr::select(
      -c(1:4), -se, -z, -tidyselect::starts_with("ci"),
      -tidyselect::starts_with("std")
    ) %>%
    dplyr::select(effect, everything()) %>%
    dplyr::group_by(group) %>%
    dplyr::group_split(.keep = FALSE) %>%
    purrr::map2(.y = seq_along(.), ~ {
      if ("label" %in% names(.x)) {
        x <- dplyr::select(.x, -label)
      } else {
        x <- .x
      }
      purrr::set_names(x, c(
        "effect",
        paste0("est_SES_", .y), paste0("p_SES_", .y)
      ))
    }) %>%
    purrr::reduce(dplyr::full_join, by = "effect") %>%
    {
      dplyr::bind_cols(
        dplyr::select(., effect),
        dplyr::select(., -effect) %>% round(3)
      )
    } %>%
    dplyr::select(
      effect, tidyselect::starts_with("est"),
      tidyselect::everything()
    ) %>%
    dplyr::mutate(dplyr::across(tidyselect::starts_with("p_"), ~ p_ind(.))) %>%
    dplyr::select(
      effect, tidyselect::ends_with("_1"),
      tidyselect::ends_with("_2"),
      tidyselect::ends_with("_3")
    )
}


model_path_folder <- list.files("/Users/siard/Library/Mobile Documents/com~apple~CloudDocs/Statistics/riclpm r output/modelfits", pattern = ".rds", full.names = TRUE)
model_path_folder_filename <- list.files("/Users/siard/Library/Mobile Documents/com~apple~CloudDocs/Statistics/riclpm r output/modelfits", pattern = ".rds", full.names = FALSE)

end_h <- start_h <- Sys.time()
tt <- c()
all_model_paths <- seq(model_path_folder)
for (i in all_model_paths) {
  print(model_path_folder_filename[i])
  tt <- c(tt, base::difftime(end_h, start_h, units = "sec"))
  t <- mean(tt) * (length(all_model_paths) - i)
  if (t > 3600) {
    t <- t / 3600
    t_unit <- "hrs"
  } else if (t > 60) {
    t <- t / 60
    t_unit <- "mins"
  } else {
    t_unit <- "secs"
  }
  cat("\r", all_model_paths[i], " ",
    format(round(i / length(all_model_paths) * 100, 2), nsmall = 2),
    "% \t ±",
    format(round(t, 2), nsmall = 2), " ", t_unit, " remaining \t",
    sep = ""
  )
  start_h <- Sys.time()
  tryCatch(
    {
      x <- readRDS(model_path_folder[i])
      if (length(x) != 3 || grepl("\nz[1-3] ~ riBMI", x[[2]])) {

      } else {
        xdata <- x[[3]]
        if (any(names(xdata) == "z3")) {
          lower_percentile <- quantile(xdata$z3, 0.01)[[1]]
          upper_percentile <- quantile(xdata$z3, 0.99)[[1]]
          xdata <- xdata[xdata$z3 >= lower_percentile & xdata$z3 <= upper_percentile, ]
        }
        xdata_scale <- xdata[
          c(grep("id|ses", names(xdata), invert = TRUE))
        ] %>% as.data.frame()
        xdata_scale <- scale(xdata_scale, center = FALSE) %>% as.data.frame()
        xdata_scale$id <- xdata$id
        xdata_scale$ses <- xdata$ses
        model_data <- dplyr::select(xdata_scale, id, tidyselect::everything())
        model_syntax <- paste("#", x[[2]])
        model_fit <- lavaan::lavaan(
          model = model_syntax,
          data = model_data,
          missing = "fiml",
          group = "ses",
          meanstructure = TRUE,
          int.ov.free = TRUE,
          estimator = "MLR"
        )
        cat("\n\n\r", report_performance_color(model_fit))
        comp_ses_df <- comp_ses(model_fit)
        knitr::kable(comp_ses_df, format = "markdown") %>% print()
        comp_ses_col_diff <- comp_ses_df %>%
          dplyr::select(tidyselect::starts_with("est_SES")) %>%
          dplyr::rowwise() %>%
          dplyr::mutate(diffSES = abs(est_SES_1 - est_SES_2) +
            abs(est_SES_2 - est_SES_3) +
            abs(est_SES_1 - est_SES_3)) %>%
          dplyr::select(diffSES) %>%
          colSums() %>%
          unlist(use.names = FALSE)
        paste0("\nSES diff total: ", comp_ses_col_diff, "\n") %>% cat()
        model_list <- list(
          model_index = i,
          fit = model_fit,
          syntax = model_syntax,
          data = model_data,
          ses_diff = comp_ses_col_diff
        )
        saveRDS(model_list, paste0("/Users/siard/Library/Mobile Documents/com~apple~CloudDocs/Thesis/models_data/", "model_", i, ".rds"))
      }
    },
    error = function(e) {
      print(e)
    }
  )

  end_h <- Sys.time()
  if ((i %% 10) == 0) {
    gc(reset = TRUE)
  }
}